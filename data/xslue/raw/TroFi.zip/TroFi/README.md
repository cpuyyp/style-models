preprocessed from https://github.com/shaharlinial/metaphor_detection

