Due to the license issue, we only provide the pre-processing script for GYFAC dataset

NOTE:
We merged Family_Relationships and Entertainment_Music into single file. In order to make a separate classifier for each domain, please use the split in the original/ directory.

