
The ShortRomance text are crawled from the following websites. The copyright of the messages are owned by the original writer of the websites. Some preprocessing (i.e., filtering noisy text, removing duplication) is maded.

http://www.goodmorningtextmessages.com/2013/06/romantic-text-messages-for-her.html
https://www.travelandleisure.com/travel-tips/romantic-love-messages-for-him-and-her
https://www.amoramargo.com/en/sweet-text-messages-for-her/
https://www.techjunkie.com/best-romantic-text-messages-for-girlfriend/
https://liveboldandbloom.com/10/relationships/love-messages-for-wife
https://www.marriagefamilystrong.com/sweet-love-text-messages/
https://pairedlife.com/love/love-messages-for-him-and-her
https://truelovewords.com/sweet-love-text-messages-for-him/
https://www.serenataflowers.com/pollennation/love-text-messages/
https://www.greetingcardpoet.com/73-love-text-messages/
https://www.wishesmsg.com/heart-touching-love-messages/
