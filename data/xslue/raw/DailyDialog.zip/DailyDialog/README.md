`processed` contains the pre-processed version of the `original` dataset using https://github.com/Sanghoon94/DailyDialogue-Parser
